# Change Log

## [3.1.0]

- Add ability to use extension without installing on remote

## [3.0.3]

- Add license
- Update dependencies

## [3.0.2]

- Add Go to Last Edit Location button
- Mess up semantic versioning

## [0.2.1]

- Various fixes and improvements

## [0.2.0]

- Add ability to change icon style

## [0.1.1]

- Changed icon and description

## [0.1]

- Initial release
