Private changes to third-party libraries

## SVGO
sortDefsChildren bug fix